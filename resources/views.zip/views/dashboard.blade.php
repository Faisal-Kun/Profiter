@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <h3>Dashboard</h3>

    <a href="/produk/tambah" class="btn btn-warning">
    <i class="bi bi-plus-circle"></i>
    Tambah Produk
</a>

</div>

<div class="row g-4">

    <div class="col-md-3">
        <div class="card card-dashboard">
            <div class="card-body">
                <h6>Pendapatan</h6>
                <h3>Rp375.000</h3>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card card-dashboard">
            <div class="card-body">
                <h6>Laba</h6>
                <h3 class="text-success">Rp150.000</h3>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card card-dashboard">
            <div class="card-body">
                <h6>Produk</h6>
                <h3>2</h3>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card card-dashboard">
            <div class="card-body">
                <h6>Terjual</h6>
                <h3>25</h3>
            </div>
        </div>
    </div>

</div>

<hr class="my-5">

<h4 class="mb-4">Produk Hari Ini</h4>

<div class="row g-4">

    <div class="col-lg-4">

        <div class="card product-card">

            <img src="https://images.unsplash.com/photo-1562967916-eb82221dfb92?w=800"
     class="card-img-top">

            <div class="card-body">

                <h5>Ayam Crispy</h5>

                <p>Harga : Rp15.000</p>
                <p>Produksi : 30</p>
                <p>Terjual : 25</p>
                <p>Sisa : 5</p>

                <a href="/produk/detail" class="btn btn-warning w-100">
    Detail Produk
</a>

            </div>

        </div>

    </div>

</div>

@endsection