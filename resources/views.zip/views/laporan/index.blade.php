@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3>Laporan</h3>
        <p class="text-muted mb-0">Ringkasan penjualan dan produksi</p>
    </div>

    <button class="btn btn-warning">
        <i class="bi bi-printer"></i>
        Cetak Laporan
    </button>
</div>

<!-- Ringkasan -->

<div class="row g-4 mb-5">

    <div class="col-md-4">
        <div class="card card-dashboard">
            <div class="card-body">
                <h6>Total Penjualan</h6>
                <h3>Rp375.000</h3>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card card-dashboard">
            <div class="card-body">
                <h6>Total Produksi</h6>
                <h3>50</h3>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card card-dashboard">
            <div class="card-body">
                <h6>Total Laba</h6>
                <h3 class="text-success">Rp150.000</h3>
            </div>
        </div>
    </div>

</div>

<!-- Filter -->

<div class="card mb-4">
    <div class="card-body">

        <h5 class="mb-3">Filter Laporan</h5>

        <div class="row g-3">

            <div class="col-md-5">
                <label class="form-label">Tanggal Mulai</label>
                <input type="date" class="form-control">
            </div>

            <div class="col-md-5">
                <label class="form-label">Tanggal Akhir</label>
                <input type="date" class="form-control">
            </div>

            <div class="col-md-2 d-flex align-items-end">
                <button class="btn btn-warning w-100">
                    Tampilkan
                </button>
            </div>

        </div>

    </div>
</div>

<!-- Tabel -->

<div class="card">

    <div class="card-body">

        <h5 class="mb-4">Laporan Penjualan</h5>

        <div class="table-responsive">

            <table class="table table-hover align-middle">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Produk</th>
                        <th>Produksi</th>
                        <th>Terjual</th>
                        <th>Pendapatan</th>
                        <th>Laba</th>
                    </tr>
                </thead>

                <tbody>

                    <tr>
                        <td>1</td>
                        <td>12 Agustus 2026</td>
                        <td>Ayam Crispy</td>
                        <td>30</td>
                        <td>25</td>
                        <td>Rp375.000</td>
                        <td class="text-success">Rp150.000</td>
                    </tr>

                    <tr>
                        <td>2</td>
                        <td>11 Agustus 2026</td>
                        <td>Ayam Geprek</td>
                        <td>20</td>
                        <td>15</td>
                        <td>Rp270.000</td>
                        <td class="text-success">Rp100.000</td>
                    </tr>

                </tbody>

            </table>

        </div>

    </div>

</div>

@endsection