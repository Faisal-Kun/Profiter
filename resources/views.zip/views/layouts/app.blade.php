<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ProfitKu</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body{
            background:#f5f6fa;
            font-family:Arial, Helvetica, sans-serif;
        }

        .sidebar{
            width:250px;
            height:100vh;
            background:#1f2937;
            position:fixed;
            left:0;
            top:0;
        }

.logo{
    height:80px;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:10px;

    color:#fff;
    font-size:30px;
    font-weight:700;

    border-bottom:1px solid rgba(255,255,255,.1);
}

        .sidebar a{
            display:block;
            padding:15px 25px;
            color:#ddd;
            text-decoration:none;
        }

        .sidebar a:hover,
        .sidebar a.active{
            background:#fbbf24;
            color:#000;
        }

        .content{
            margin-left:250px;
        }

        .topbar{
            background:#fff;
            height:70px;
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:0 30px;
            box-shadow:0 2px 8px rgba(0,0,0,.08);
        }

        .card-dashboard{
            border:none;
            border-radius:15px;
            box-shadow:0 5px 15px rgba(0,0,0,.08);
        }

        .product-card{
            border:none;
            border-radius:15px;
            overflow:hidden;
            box-shadow:0 5px 15px rgba(0,0,0,.08);
        }

        .product-card img{
            width:100%;
            height:180px;
            object-fit:cover;
        }
    </style>
</head>

<body>

@include('partials.sidebar')

<div class="content">

    @include('partials.navbar')

    <div class="container-fluid p-4">
        @yield('content')
    </div>

</div>

</body>
</html>