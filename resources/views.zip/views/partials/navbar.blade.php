<div class="topbar">

    <div>
        <h4 class="mb-0">

            @if(request()->is('/'))
                Dashboard

            @elseif(request()->is('produk'))
                Produk

            @elseif(request()->is('produk/tambah'))
                Tambah Produk

            @elseif(request()->is('produk/detail'))
                Detail Produk

            @elseif(request()->is('produksi'))
                Produksi

            @elseif(request()->is('produksi/tambah'))
                Tambah Produksi

            @elseif(request()->is('penjualan'))
                Penjualan

            @elseif(request()->is('penjualan/tambah'))
                Tambah Penjualan

            @elseif(request()->is('pengeluaran'))
                Pengeluaran

            @elseif(request()->is('pengeluaran/tambah'))
                Tambah Pengeluaran

            @elseif(request()->is('laporan'))
                Laporan

            @endif

        </h4>
    </div>

    <div>
        <i class="bi bi-bell fs-5 me-3"></i>

        <img src="https://i.pravatar.cc/40"
             class="rounded-circle">
    </div>

</div>