<div class="sidebar">

    <div class="logo">
        <span>🐔</span>
        <span>ProfitKu</span>
    </div>

    <a href="/" class="{{ request()->is('/') ? 'active' : '' }}">
        <i class="bi bi-house"></i>
        Dashboard
    </a>

    <a href="/produk" class="{{ request()->is('produk*') ? 'active' : '' }}">
        <i class="bi bi-box"></i>
        Produk
    </a>

    <a href="/produksi" class="{{ request()->is('produksi*') ? 'active' : '' }}">
        <i class="bi bi-box-seam"></i>
        Produksi
    </a>

    <a href="/penjualan" class="{{ request()->is('penjualan*') ? 'active' : '' }}">
        <i class="bi bi-cart"></i>
        Penjualan
    </a>

    <a href="/pengeluaran" class="{{ request()->is('pengeluaran*') ? 'active' : '' }}">
        <i class="bi bi-wallet2"></i>
        Pengeluaran
    </a>

    <a href="/laporan" class="{{ request()->is('laporan*') ? 'active' : '' }}">
        <i class="bi bi-file-earmark-bar-graph"></i>
        Laporan
    </a>

</div>