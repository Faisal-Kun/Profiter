@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3>Detail Pengeluaran</h3>
        <p class="text-muted mb-0">Informasi pengeluaran usaha</p>
    </div>

    <a href="/pengeluaran" class="btn btn-secondary">
        Kembali
    </a>
</div>

<div class="card">
    <div class="card-body">

        <h5 class="mb-4">Informasi Pengeluaran</h5>

        <div class="row mb-3">
            <div class="col-sm-4 text-muted">
                Tanggal
            </div>
            <div class="col-sm-8">
                12 Agustus 2026
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-sm-4 text-muted">
                Keterangan
            </div>
            <div class="col-sm-8">
                Membeli ayam
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-sm-4 text-muted">
                Kategori
            </div>
            <div class="col-sm-8">
                <span class="badge bg-primary">
                    Bahan Baku
                </span>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-sm-4 text-muted">
                Jumlah Pengeluaran
            </div>
            <div class="col-sm-8">
                <strong>Rp150.000</strong>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-sm-4 text-muted">
                Catatan
            </div>
            <div class="col-sm-8">
                Pembelian bahan baku untuk produksi.
            </div>
        </div>

        <div class="d-flex gap-2">

            <button class="btn btn-warning">
                <i class="bi bi-pencil"></i>
                Edit
            </button>

            <button class="btn btn-outline-danger">
                <i class="bi bi-trash"></i>
                Hapus
            </button>

        </div>

    </div>
</div>

@endsection