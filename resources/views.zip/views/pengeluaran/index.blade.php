@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3>Pengeluaran</h3>
        <p class="text-muted mb-0">Catatan pengeluaran usaha</p>
    </div>

    <a href="/pengeluaran/tambah" class="btn btn-warning">
    <i class="bi bi-plus-circle"></i>
    Tambah Pengeluaran
</a>
</div>

<div class="card">
    <div class="card-body">

        <div class="table-responsive">
            <table class="table table-hover align-middle">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th>Kategori</th>
                        <th>Jumlah</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>

                    <tr>
                        <td>1</td>
                        <td>12 Agustus 2026</td>
                        <td>Membeli ayam</td>
                        <td>
                            <span class="badge bg-primary">Bahan Baku</span>
                        </td>
                        <td>Rp150.000</td>
                        <td>
                            <button class="btn btn-sm btn-warning">
                                Detail
                            </button>
                        </td>
                    </tr>

                    <tr>
                        <td>2</td>
                        <td>12 Agustus 2026</td>
                        <td>Membeli minyak goreng</td>
                        <td>
                            <span class="badge bg-primary">Bahan Baku</span>
                        </td>
                        <td>Rp75.000</td>
                        <td>
                           <a href="/pengeluaran/detail" class="btn btn-sm btn-warning">
    Detail
</a>
                        </td>
                    </tr>

                    <tr>
                        <td>3</td>
                        <td>11 Agustus 2026</td>
                        <td>Gas LPG</td>
                        <td>
                            <span class="badge bg-secondary">Operasional</span>
                        </td>
                        <td>Rp25.000</td>
                        <td>
                            <button class="btn btn-sm btn-warning">
                                Detail
                            </button>
                        </td>
                    </tr>

                </tbody>

            </table>
        </div>

    </div>
</div>

@endsection