@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3>Tambah Pengeluaran</h3>
        <p class="text-muted mb-0">Tambahkan pengeluaran baru</p>
    </div>

    <a href="/pengeluaran" class="btn btn-secondary">
        Kembali
    </a>
</div>

<div class="card">
    <div class="card-body">

        <div class="mb-3">
            <label class="form-label">Tanggal</label>
            <input type="date" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label">Keterangan</label>
            <input type="text" class="form-control"
                   placeholder="Contoh: Membeli ayam">
        </div>

        <div class="mb-3">
            <label class="form-label">Kategori</label>
            <select class="form-select">
                <option selected disabled>Pilih Kategori</option>
                <option>Bahan Baku</option>
                <option>Operasional</option>
                <option>Peralatan</option>
                <option>Lainnya</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Jumlah Pengeluaran</label>
            <input type="number" class="form-control"
                   placeholder="Contoh: 150000">
        </div>

        <div class="mb-3">
            <label class="form-label">Catatan</label>
            <textarea class="form-control" rows="3"
                      placeholder="Tambahkan catatan jika diperlukan"></textarea>
        </div>

        <button class="btn btn-warning">
            <i class="bi bi-save"></i>
            Simpan Pengeluaran
        </button>

    </div>
</div>

@endsection