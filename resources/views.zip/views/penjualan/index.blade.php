@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3>Penjualan</h3>
        <p class="text-muted mb-0">Riwayat penjualan produk</p>
    </div>

    <a href="/penjualan/tambah" class="btn btn-warning">
    <i class="bi bi-plus-circle"></i>
    Tambah Penjualan
</a>
</div>

<div class="card">
    <div class="card-body">

        <div class="table-responsive">
            <table class="table table-hover align-middle">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Produk</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Total</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>

                    <tr>
                        <td>1</td>
                        <td>12 Agustus 2026</td>
                        <td>Ayam Crispy</td>
                        <td>Rp15.000</td>
                        <td>5</td>
                        <td>Rp75.000</td>
                        <td>
                            <button class="btn btn-sm btn-warning">
                                Detail
                            </button>
                        </td>
                    </tr>

                    <tr>
                        <td>2</td>
                        <td>12 Agustus 2026</td>
                        <td>Ayam Geprek</td>
                        <td>Rp18.000</td>
                        <td>3</td>
                        <td>Rp54.000</td>
                        <td>
                            <button class="btn btn-sm btn-warning">
                                Detail
                            </button>
                        </td>
                    </tr>

                    <tr>
                        <td>3</td>
                        <td>11 Agustus 2026</td>
                        <td>Ayam Crispy</td>
                        <td>Rp15.000</td>
                        <td>7</td>
                        <td>Rp105.000</td>
                        <td>
                           <a href="/penjualan/detail" class="btn btn-sm btn-warning">
    Detail
</a>
                        </td>
                    </tr>

                </tbody>

            </table>
        </div>

    </div>
</div>

@endsection