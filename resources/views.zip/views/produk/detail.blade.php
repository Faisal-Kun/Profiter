@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3>Detail Produk</h3>
        <p class="text-muted mb-0">Informasi lengkap produk</p>
    </div>

    <a href="/produk" class="btn btn-secondary">
        Kembali
    </a>
</div>

<div class="row g-4">

    <!-- Foto Produk -->
    <div class="col-md-5">

        <div class="card">
            <img src="https://images.unsplash.com/photo-1562967916-eb82221dfb92?w=800"
                 class="card-img-top">

            <div class="card-body text-center">
                <h4>Ayam Crispy</h4>
                <p class="text-muted mb-0">
                    Produk makanan
                </p>
            </div>
        </div>

    </div>

    <!-- Informasi Produk -->
    <div class="col-md-7">

        <div class="card">
            <div class="card-body">

                <h5 class="mb-4">Informasi Produk</h5>

                <div class="row mb-3">
                    <div class="col-sm-5 text-muted">
                        Nama Produk
                    </div>
                    <div class="col-sm-7">
                        Ayam Crispy
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-sm-5 text-muted">
                        Harga
                    </div>
                    <div class="col-sm-7">
                        Rp15.000
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-sm-5 text-muted">
                        Total Produksi
                    </div>
                    <div class="col-sm-7">
                        30
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-sm-5 text-muted">
                        Total Terjual
                    </div>
                    <div class="col-sm-7">
                        25
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="col-sm-5 text-muted">
                        Stok Tersisa
                    </div>
                    <div class="col-sm-7">
                        <span class="badge bg-success">
                            5
                        </span>
                    </div>
                </div>

                <div class="d-flex gap-2">

                   <a href="/produk/edit" class="btn btn-warning">
    <i class="bi bi-pencil"></i>
    Edit Produk
</a>

                    <button class="btn btn-outline-danger">
                        <i class="bi bi-trash"></i>
                        Hapus
                    </button>

                </div>

            </div>
        </div>

    </div>

</div>

@endsection