@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3>Edit Produk</h3>
        <p class="text-muted mb-0">Ubah informasi produk</p>
    </div>

    <a href="/produk/detail" class="btn btn-secondary">
        Kembali
    </a>
</div>

<div class="card">
    <div class="card-body">

        <div class="mb-3">
            <label class="form-label">Nama Produk</label>
            <input type="text"
                   class="form-control"
                   value="Ayam Crispy">
        </div>

        <div class="mb-3">
            <label class="form-label">Harga</label>
            <input type="number"
                   class="form-control"
                   value="15000">
        </div>

        <div class="mb-3">
            <label class="form-label">Jumlah Produksi</label>
            <input type="number"
                   class="form-control"
                   value="30">
        </div>

        <div class="mb-3">
            <label class="form-label">Foto Produk</label>
            <input type="file" class="form-control">
        </div>

        <div class="mb-4">
            <label class="form-label">Foto Saat Ini</label>
            <br>

            <img src="https://images.unsplash.com/photo-1562967916-eb82221dfb92?w=800"
                 width="200"
                 class="rounded">
        </div>

        <button class="btn btn-warning">
            <i class="bi bi-save"></i>
            Simpan Perubahan
        </button>

    </div>
</div>

@endsection