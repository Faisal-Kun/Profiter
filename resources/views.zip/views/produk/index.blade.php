@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3>Produk</h3>
        <p class="text-muted mb-0">Daftar produk yang tersedia</p>
    </div>

    <button class="btn btn-warning">
        <i class="bi bi-plus-circle"></i>
        Tambah Produk
    </button>
</div>

<div class="row g-4">

    <div class="col-md-4">
        <div class="card product-card">

            <img src="https://images.unsplash.com/photo-1562967916-eb82221dfb92?w=800"
                 class="card-img-top">

            <div class="card-body">

                <h5>Ayam Crispy</h5>

                <p class="text-muted mb-2">
                    Harga: Rp15.000
                </p>

                <p class="mb-1">
                    Produksi: 30
                </p>

                <p class="mb-3">
                    Stok: 5
                </p>

                <div class="d-flex gap-2">

                    <a href="/produk/detail" class="btn btn-warning w-100">
    Detail
</a>

                    <button class="btn btn-outline-danger">
                        <i class="bi bi-trash"></i>
                    </button>

                </div>

            </div>

        </div>
    </div>

</div>

@endsection