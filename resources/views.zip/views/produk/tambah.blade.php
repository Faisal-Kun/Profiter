@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3>Tambah Produk</h3>
        <p class="text-muted mb-0">Tambahkan produk baru</p>
    </div>

    <a href="/produk" class="btn btn-secondary">
        Kembali
    </a>
</div>

<div class="card">
    <div class="card-body">

        <div class="mb-3">
            <label class="form-label">Nama Produk</label>
            <input type="text" class="form-control" placeholder="Contoh: Ayam Crispy">
        </div>

        <div class="mb-3">
            <label class="form-label">Harga</label>
            <input type="number" class="form-control" placeholder="15000">
        </div>

        <div class="mb-3">
            <label class="form-label">Jumlah Produksi</label>
            <input type="number" class="form-control" placeholder="30">
        </div>

        <div class="mb-3">
            <label class="form-label">Foto Produk</label>
            <input type="file" class="form-control">
        </div>

        <button class="btn btn-warning">
            <i class="bi bi-save"></i>
            Simpan Produk
        </button>

    </div>
</div>

@endsection