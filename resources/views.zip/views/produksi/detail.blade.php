@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3>Detail Produksi</h3>
        <p class="text-muted mb-0">Informasi produksi produk</p>
    </div>

    <a href="/produksi" class="btn btn-secondary">
        Kembali
    </a>
</div>

<div class="card">
    <div class="card-body">

        <h5 class="mb-4">Informasi Produksi</h5>

        <div class="row mb-3">
            <div class="col-sm-4 text-muted">
                Tanggal Produksi
            </div>
            <div class="col-sm-8">
                12 Agustus 2026
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-sm-4 text-muted">
                Produk
            </div>
            <div class="col-sm-8">
                Ayam Crispy
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-sm-4 text-muted">
                Jumlah Produksi
            </div>
            <div class="col-sm-8">
                30
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-sm-4 text-muted">
                Terjual
            </div>
            <div class="col-sm-8">
                25
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-sm-4 text-muted">
                Sisa
            </div>
            <div class="col-sm-8">
                <span class="badge bg-success">
                    5
                </span>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-sm-4 text-muted">
                Catatan
            </div>
            <div class="col-sm-8">
                Produksi ayam crispy untuk penjualan hari ini.
            </div>
        </div>

        <div class="d-flex gap-2">

            <button class="btn btn-warning">
                <i class="bi bi-pencil"></i>
                Edit
            </button>

            <button class="btn btn-outline-danger">
                <i class="bi bi-trash"></i>
                Hapus
            </button>

        </div>

    </div>
</div>

@endsection