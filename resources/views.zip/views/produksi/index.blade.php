@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3>Produksi</h3>
        <p class="text-muted mb-0">Catatan produksi produk</p>
    </div>

   <a href="/produksi/tambah" class="btn btn-warning">
    <i class="bi bi-plus-circle"></i>
    Tambah Produksi
</a>
</div>

<div class="card">
    <div class="card-body">

        <div class="table-responsive">
            <table class="table table-hover align-middle">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Produk</th>
                        <th>Jumlah Produksi</th>
                        <th>Terjual</th>
                        <th>Sisa</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>

                    <tr>
                        <td>1</td>
                        <td>12 Agustus 2026</td>
                        <td>Ayam Crispy</td>
                        <td>30</td>
                        <td>25</td>
                        <td>
                            <span class="badge bg-success">5</span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-warning">
                                Detail
                            </button>
                        </td>
                    </tr>

                    <tr>
                        <td>2</td>
                        <td>12 Agustus 2026</td>
                        <td>Ayam Geprek</td>
                        <td>20</td>
                        <td>15</td>
                        <td>
                            <span class="badge bg-success">5</span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-warning">
                                Detail
                            </button>
                        </td>
                    </tr>

                    <tr>
                        <td>3</td>
                        <td>11 Agustus 2026</td>
                        <td>Ayam Crispy</td>
                        <td>25</td>
                        <td>20</td>
                        <td>
                            <span class="badge bg-success">5</span>
                        </td>
                        <td>
                           <a href="/produksi/detail" class="btn btn-sm btn-warning">
    Detail
</a>
                        </td>
                    </tr>

                </tbody>

            </table>
        </div>

    </div>
</div>

@endsection