@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3>Tambah Produksi</h3>
        <p class="text-muted mb-0">Tambahkan data produksi baru</p>
    </div>

    <a href="/produksi" class="btn btn-secondary">
        Kembali
    </a>
</div>

<div class="card">
    <div class="card-body">

        <div class="mb-3">
            <label class="form-label">Tanggal Produksi</label>
            <input type="date" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label">Produk</label>
            <select class="form-select">
                <option selected disabled>Pilih Produk</option>
                <option>Ayam Crispy</option>
                <option>Ayam Geprek</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Jumlah Produksi</label>
            <input type="number" class="form-control" placeholder="Contoh: 30">
        </div>

        <div class="mb-3">
            <label class="form-label">Catatan</label>
            <textarea class="form-control" rows="3"
                placeholder="Tambahkan catatan jika diperlukan"></textarea>
        </div>

        <button class="btn btn-warning">
            <i class="bi bi-save"></i>
            Simpan Produksi
        </button>

    </div>
</div>

@endsection